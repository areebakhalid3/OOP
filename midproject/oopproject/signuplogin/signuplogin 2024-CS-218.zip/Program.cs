﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace signuplogin
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string path = "D:\\oop\\signuplogin\\file.txt";
            string[] email = new string[100];
            string[] password = new string[100];
            string logemail = "", logpassword = "";
            int choice;

            do
            {
                Console.Clear();
                choice = Menu();
                Console.Clear();

                if (choice == 1)
                {
                    if (SignUp(path,email, password))
                    {
                        Console.SetCursorPosition(50, 25);
                        Console.WriteLine("Registeration successful!");
                    }
                    else
                    {
                        Console.SetCursorPosition(50, 25);
                        Console.WriteLine("Registeration failed.");
                    }

                    Console.SetCursorPosition(50, 27);
                    Console.WriteLine("Press any key to return to the menu.");
                    Console.ReadKey();

                }
                else if (choice == 2)
                {

                    Console.Clear();
                    Console.SetCursorPosition(50, 3);
                    Console.WriteLine("=============================================================================");
                    Console.SetCursorPosition(50, 4);
                    Console.WriteLine("==                       L      O      G      I      N                     ==");
                    Console.SetCursorPosition(50, 6);
                    Console.WriteLine("==                           N      O      W      !                        ==");
                    Console.SetCursorPosition(50, 7);
                    Console.WriteLine("=============================================================================");

                    Console.SetCursorPosition(50, 12);
                    Console.WriteLine("Enter your email: ");
                    logemail = Console.ReadLine();
                    Console.SetCursorPosition(50, 14);
                    Console.WriteLine("Enter your password: ");
                    logpassword = Console.ReadLine();

                    if (SignIn(email, password, ref logemail, ref logpassword, path))
                    {
                        Console.SetCursorPosition(50, 25);
                        Console.WriteLine("Login successful!");
                    }
                    else
                    {
                        Console.SetCursorPosition(50, 25);
                        Console.WriteLine("Invalid email or password! Login failed.");
                    }

                    Console.SetCursorPosition(50, 27);
                    Console.WriteLine("Press any key to return to the menu.");
                    Console.ReadKey();

                }
            }
            while (choice != 3);

            Console.SetCursorPosition(50, 27);
            Console.WriteLine("Thank you for using. Goodbye!");
            Console.ReadLine();
        }


        static bool SignUp(string path,string[] email, string[] password){   

    bool isvalidemail = false, isvalidpass = false;
            string newEmail = "", newPassword = "";


            Console.SetCursorPosition(50, 3);
        Console.WriteLine("=============================================================================");
        Console.SetCursorPosition(50, 4);
        Console.WriteLine("==                  R     E    G     I    S     T     E     R              ==");
        Console.SetCursorPosition(50, 6);
        Console.WriteLine("==                           N      O      W      !                        ==");
        Console.SetCursorPosition(50, 7);
        Console.WriteLine("=============================================================================");

    while(!isvalidemail){
    
    Console.SetCursorPosition(50, 10);
    Console.WriteLine("Enter your email(must contain @) [Enter 'q' to exit]: ");
    newEmail= Console.ReadLine();

    if(newEmail=="q"||newEmail=="Q"){
    Console.SetCursorPosition(50, 12);
    Console.WriteLine("Exiting registration.Goodbye!                                         ");
    return false;
}

bool isemptyemail = true;
for (int i = 0; i<newEmail.Length; i++)
{
    if(newEmail[i] != ' ')
    {
        isemptyemail = false;
        break;
    }
}
if (isemptyemail)
{
    Console.SetCursorPosition(50, 12);
    Console.WriteLine("Email cannot be empty.                                                                                                           ");
    continue;
}

bool hasat = false;
int idx = -1;
int countofat = 0;

for (int em = 0;em< newEmail.Length;em++)
{
    if (newEmail[em] == '@')
    {
        hasat = true;
        idx = em;
        countofat++;
    }
}
if (!hasat || countofat > 1 || idx == 0 || idx==newEmail.Length-1)
{
    Console.SetCursorPosition(50, 12);
    Console.WriteLine("Invalid email format.Missing or misplaced '@' or multiple '@' ");
    Console.SetCursorPosition(50, 10);
    Console.WriteLine("                                                                                                                                                                         ");
    continue;
}

Console.SetCursorPosition(50, 12);
Console.WriteLine("                                                                                                                                       ");
isvalidemail = true;
}

    while (!isvalidpass)
{
    Console.SetCursorPosition(50, 17);
    Console.WriteLine("Create a secure password (Password must contain at");
    Console.SetCursorPosition(50, 18);
    Console.WriteLine("least one uppercase letter, one lowercase letter,");
    Console.SetCursorPosition(50, 19);
    Console.WriteLine("one digit,one special character and must ");
    Console.SetCursorPosition(50, 20);
    Console.WriteLine("be 6 characters long)[Enter 'q' to exit]: ");
    newPassword= Console.ReadLine();

    if (newPassword == "q" || newPassword == "Q")
    {
        Console.SetCursorPosition(50, 22);
        Console.WriteLine("Exiting.Goodbye!");
        return false;
    }

    bool isemptypass = true;
    for (int i = 0; i<newPassword.Length; i++)
    {
        if (newPassword[i] != ' ')
        {
            isemptypass = false;
            break;
        }
    }
    if (isemptypass)
    {
        Console.SetCursorPosition(50, 22);
        Console.WriteLine("Error: Password cannot be empty.                                                          ");
        Console.SetCursorPosition(50, 20);
        Console.WriteLine("                                                                                         ");
        continue;
    }

    int passlength = 0;
    bool hasupper = false, haslower = false, hasdigit = false, hasspecial = false;

    while(passlength < newPassword.Length)
    {
        if (newPassword[passlength] >= 'A' && newPassword[passlength] <= 'Z')
        {
            hasupper = true;
        }
        if (newPassword[passlength] >= 'a' && newPassword[passlength] <= 'z')
        {
            haslower = true;
        }
        if (newPassword[passlength] >= '0' && newPassword[passlength] <= '9')
        {
            hasdigit = true;
        }
        if ((newPassword[passlength] == '!' || newPassword[passlength] == '@' || newPassword[passlength] == '#' || newPassword[passlength] == '$' ||
             newPassword[passlength] == '%' || newPassword[passlength] == '^' || newPassword[passlength] == '&' || newPassword[passlength] == '*' ||
             newPassword[passlength] == '(' || newPassword[passlength] == ')' || newPassword[passlength] == '-' || newPassword[passlength] == '_'))
        {
            hasspecial = true;
        }
        passlength++;
    }

    if (newPassword.Length < 6)
    {
        Console.SetCursorPosition(50, 22);
        Console.WriteLine("Password must be atleast 6 characters long.Please try again.");
        Console.SetCursorPosition(50, 20);
        Console.WriteLine("                                                                                                                                                                  ");
        continue;
    }

    if (!hasupper || !haslower || !hasdigit || !hasspecial)
    {
        Console.SetCursorPosition(50, 22);
        Console.WriteLine("Password requirements not met.Please enter a valid password.");
        Console.SetCursorPosition(50, 20);
        Console.WriteLine("                                                                                                                                                             ");
        continue;
    }

    isvalidpass = true;
    Console.SetCursorPosition(50, 22);
    Console.WriteLine("                                                                                               ");
}
            StreamWriter file = new StreamWriter(path, true);
            file.WriteLine(newEmail + "," + newPassword);
            file.Flush();
            file.Close();

            return true;
}
        static bool SignIn(string[] email, string[] password, ref string logemail, ref string logpassword, string path)
        {
            bool valid = false;
            int x = 0;

            if (File.Exists(path))
            {
                StreamReader fileVariable = new StreamReader(path);
                string record;

                while ((record = fileVariable.ReadLine()) != null)
                {
                    email[x] = getData(record, 1);
                    password[x] = getData(record, 2);  

                    if (logemail == email[x] && logpassword == password[x])
                    {
                        valid = true;
                        break;
                    }

                    x++;
                    if (x >= email.Length)
                    {
                        break;
                    }
                }
                fileVariable.Close();
            }
            else
            {
                Console.SetCursorPosition(50, 16);
                Console.WriteLine("User data file not found.");
            }

            return valid;  
        }

    static string getData(string record,int field)
{
    int comma = 1;
    string item = "";
    for(int x = 0; x < record.Length; x++)
    {
        if(record[x] == ',')
        {
            comma++;
        }
        else if (comma== field)
        {
            item=item+record[x];
        }
    }
    return item;
}

        static int Menu()
        {
            Console.SetCursorPosition(40, 3);
            Console.WriteLine("=============================================================================");
            Console.SetCursorPosition(40, 5);
            Console.WriteLine("==                       M      E      N      U                            ==");
            Console.SetCursorPosition(40, 7);
            Console.WriteLine("=============================================================================");

            Console.SetCursorPosition(35, 10);
            Console.WriteLine("Welcome!");
            Console.SetCursorPosition(35, 12);
            Console.WriteLine("1. Sign up");
            Console.SetCursorPosition(35, 13);
            Console.WriteLine("2. Login");           
            Console.SetCursorPosition(35, 15);
            Console.WriteLine("Enter choice(1 or 2): ");

            int role=int.Parse(Console.ReadLine());
            while(role < 1 || role > 2)
            {
                Console.SetCursorPosition(37, 17);
                Console.WriteLine("Invalid choice. Enter again.");
                role = int.Parse(Console.ReadLine());
            }
            return role;
        }
    }
}
